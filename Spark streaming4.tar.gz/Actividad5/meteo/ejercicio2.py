import findspark
findspark.init("/opt/cloudera/parcels/CDH-6.2.0-1.cdh6.2.0.p0.967373/lib/spark")
from pyspark.sql import SparkSession
from pyspark.sql.functions import from_json, explode


spark = SparkSession.builder \
    .appName("KafkaStructuredStreaming") \
    .getOrCreate()


kafka_df = spark.readStream \
    .format("kafka") \
    .option("kafka.bootstrap.servers", "Cloudera02:9092") \
    .option("subscribe", "xcastanoaTopic") \
    .load()

json_df = kafka_df.selectExpr("CAST(value AS STRING) as json_value")


json_schema = """
    STRUCT<temperature_2m: DOUBLE, time: STRING, city: STRING, wind_speed_10m: DOUBLE>
"""


exploded_df = json_df.select(explode(from_json("json_value", "ARRAY<STRUCT<temperature_2m: DOUBLE, time: STRING, city: STRING, wind_speed_10m: DOUBLE>>")).alias("data"))


structured_df = exploded_df.select("data.temperature_2m", "data.time", "data.city", "data.wind_speed_10m")


structured_df.printSchema()

query = structured_df.writeStream \
    .outputMode("append") \
    .format("console") \
    .start()

query.awaitTermination()
