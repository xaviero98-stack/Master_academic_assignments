import requests
import json
from kafka import KafkaProducer
from requests.auth import HTTPBasicAuth
import time
import random

ciudades = [
    {"ciudad": "Barcelona", "latitud": "41.3874", "longitud": "2.1686"},
    {"ciudad": "Tarragona", "latitud": "41.1189", "longitud": "1.2445"},
    {"ciudad": "Girona", "latitud": "41.9794", "longitud": "2.8214"}
]

LIMITE = 5 
TIEMPO_LIMITE = 4500
tiempo = 0
contador = 0

inicio = time.time()

while True:
    
    latitudes = ",".join([ciudad['latitud'] for ciudad in ciudades])
    longitudes = ",".join([ciudad['longitud'] for ciudad in ciudades])
    url = "https://api.open-meteo.com/v1/forecast?latitude={}&longitude={}&current=temperature_2m,wind_speed_10m&forecast_days=1".format(latitudes, longitudes)
    
    response = requests.get(url)
    response.raise_for_status()
    datos = response.json()

    
    datos_reestructurados = []
    for i, ciudad in enumerate(ciudades):
        ciudad_data = datos[i]['current']
        ciudad_estructurada = {
            'temperature_2m': ciudad_data['temperature_2m'],
            'time': ciudad_data['time'],
            'city': ciudad['ciudad'],
            'wind_speed_10m': ciudad_data['wind_speed_10m']
        }
        datos_reestructurados.append(ciudad_estructurada)

    
    producer = KafkaProducer(
        bootstrap_servers='Cloudera02:9092',
        value_serializer=lambda v: json.dumps(v).encode('utf-8')
    )

    
    topic_name = "xcastanoaTopic"
    producer.send(topic_name, datos_reestructurados)
    print("Datos enviados al topic {}: {}".format(topic_name, json.dumps(datos_reestructurados, indent=4)))

    
    producer.close()

    contador += 1
    fin = time.time()
    tiempo = fin - inicio
    if tiempo > TIEMPO_LIMITE or contador >= LIMITE:
        break
    time.sleep(900)  