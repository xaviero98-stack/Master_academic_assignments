DELETE FROM supermarket.customers
WHERE customer_id NOT IN (SELECT customer_id
						 FROM orders);
UPDATE products
SET unit_price = 21.50
WHERE product_name = 'Chang'; 

UPDATE supermarket.products
SET unit_price = unit_price * 0.93
WHERE category_id = (SELECT category_id
					FROM supermarket.categories
					WHERE category_name = 'Dairy Products');

UPDATE supermarket.products
SET unit_price = (SELECT AVG(unit_price)
					FROM supermarket.products
					WHERE category_id = 5)
WHERE category_id = 5;

UPDATE supermarket.products
SET supplier_id = (SELECT supplier_id
				  FROM supermarket.products
				  WHERE product_name ='Chang')
WHERE supplier_id = (SELECT supplier_id
					FROM supermarket.suppliers
					WHERE company_name = 'Specialty Biscuits, Ltd');