
SELECT 
order_id,
(SELECT company_name
 FROM supermarket.customers
 WHERE orders.customer_id = customers.customer_id) AS company_name,
(SELECT country
 FROM supermarket.customers
 WHERE orders.customer_id = customers.customer_id) AS country,
order_date,
(SELECT SUM(quantity * unit_price)
 FROM supermarket.order_details
 WHERE orders.order_id = order_details.order_id) AS order_value
FROM supermarket.orders
WHERE (SELECT SUM(quantity * unit_price) ----Por alguna razon que desconozco la función ROUND no esta siedno reconocida, la sentencia correcta sería "SELECT ROUND(SUM(quantity * unit_price), 2)" 
 FROM supermarket.order_details
 WHERE orders.order_id = order_details.order_id) <= 50 AND order_date >= '1997-07-01'
ORDER BY country, company_name, order_value DESC

ALTER TABLE supermarket.categories
ADD COLUMN IVA DECIMAL(3,2) DEFAULT 0.09

UPDATE supermarket.categories
SET IVA = 0.21
WHERE category_name = 'Seafood'

