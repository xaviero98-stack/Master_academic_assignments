CREATE TABLE supermarket.suppliers (
supplier_id SMALLINT PRIMARY KEY,
company_name CHARACTER VARYING(40) NOT NULL, 
contact_name CHARACTER VARYING(30),
contact_title CHARACTER VARYING(30),
adress CHARACTER VARYING(60),
city CHARACTER VARYING(15),
region CHARACTER VARYING(15),
postal_code CHARACTER VARYING(10),
country CHARACTER VARYING(15),
phone CHARACTER VARYING(24),
fax CHARACTER VARYING(24),
homepage TEXT);


CREATE TABLE supermarket.products(
product_id SMALLINT PRIMARY KEY,
product_name CHARACTER VARYING(40) NOT NULL,
supplier_id SMALLINT REFERENCES supermarket.suppliers(supplier_id),
category_id SMALLINT REFERENCES supermarket.categories(category_id),
quantity_per_unit CHARACTER VARYING(20),
unit_price REAL,
units_in_stock SMALLINT,
units_on_order SMALLINT,
reorder_level SMALLINT,
discontinued INTEGER NOT NULL 
);

--No he especificado en las claves primarias "NOT NULL" debido a que va implícito en la restricción "PRIMARY KEY".

ALTER TABLE supermarket.order_details
ADD CONSTRAINT fk_pr_id FOREIGN KEY (product_id) REFERENCES supermarket.products(product_id);

ALTER TABLE supermarket.order_details
ADD CONSTRAINT pk_order_details PRIMARY KEY (order_id, product_id);

