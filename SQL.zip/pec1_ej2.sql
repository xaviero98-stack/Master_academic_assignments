SELECT product_id, product_name, unit_price
FROM supermarket.products
ORDER BY unit_price DESC, product_name;

SELECT country, COUNT(*) AS num_suppliers
FROM supermarket.suppliers
GROUP BY country
ORDER BY num_suppliers DESC;

SELECT product_name, unit_price
FROM supermarket.products
WHERE category_id = 8 AND unit_price <= 20
ORDER BY unit_price DESC;

SELECT city, country, COUNT(DISTINCT(products.supplier_id)) AS num_suppliers, COUNT (product_id) AS num_products
FROM supermarket.suppliers
LEFT JOIN supermarket.products
ON products.supplier_id = suppliers.supplier_id
GROUP BY city, country
HAVING COUNT(product_id) >= 4
ORDER BY num_products DESC, city;

SELECT category_name, COUNT(product_id) AS num_products, COUNT(DISTINCT(suppliers.supplier_id)) AS num_suppliers
FROM supermarket.categories
LEFT JOIN supermarket.products
ON categories.category_id = products.category_id
LEFT JOIN supermarket.suppliers
ON suppliers.supplier_id = products.supplier_id
GROUP BY category_name
ORDER BY num_products DESC, num_suppliers DESC, category_name

