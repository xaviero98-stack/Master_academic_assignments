import json
import re
from textblob import TextBlob
import findspark
findspark.init()

from pyspark import SparkContext
from pyspark.streaming import StreamingContext

sc = SparkContext(appName="NombreStreaming", master="local[2]")
sc.setLogLevel("ERROR")

ssc = StreamingContext(sc, 15)

puerto = 21005
socket_stream = ssc.socketTextStream("localhost", puerto)

windowedStream = socket_stream.window(90, 15)

def limpiador(text):
    text = re.sub(r'<[^>]*>', '', text)
    text = re.sub(r'http\S+', '', text)
    text = re.sub(r'[^\w\s]', '', text)
    text = text.lower()
    return text

def polarity(text):
    clean_content = limpiador(text)
    polarity = TextBlob(clean_content).sentiment.polarity
    if polarity > 0:
        return ("positive", 1)
    elif polarity < 0:
        return ("negative", 1)
    else:
        return ("neutral", 0)
    
stream = windowedStream.map(polarity).reduceByKey(lambda x, y: x + y)

stream.pprint(3)

ssc.start()
ssc.awaitTermination()
