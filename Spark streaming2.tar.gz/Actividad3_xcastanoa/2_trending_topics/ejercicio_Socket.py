import findspark
findspark.init()

from pyspark import SparkContext
from pyspark.streaming import StreamingContext

# Cambiad <FILL_IN> por vuestro nombre de usuario
sc = SparkContext("local[2]", "ejercicio_Socket_xcastanoa")
sc.setLogLevel("ERROR")

ssc = StreamingContext(sc, 15)

puerto = 21005
netCatStream = ssc.socketTextStream("localhost", puerto)

running_counts = (netCatStream.flatMap(lambda line: line.split(" "))
                  .filter(lambda word: not any(substr in word for substr in ["=", "noreferrer", "noopener", "<", ">"]))
                  .map(lambda word: (word, 1))
                  .reduceByKey(lambda x, y: x + y)
                  .transform(lambda rdd: rdd.sortBy(lambda x: x[1], ascending = False)))

running_counts.pprint(10)

ssc.start()
ssc.awaitTermination()
