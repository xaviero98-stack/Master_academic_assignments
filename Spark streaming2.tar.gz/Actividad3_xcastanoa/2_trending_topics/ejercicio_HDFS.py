import findspark
findspark.init()

from pyspark import SparkContext
from pyspark.streaming import StreamingContext

# Cambiad <FILL_IN> por vuestro nombre de usuario
sc = SparkContext("local[2]", "ejercicio_HDFS_xcastanoa")
sc.setLogLevel("ERROR")

ssc = StreamingContext(sc, 20)
ssc.checkpoint("checkpoint")

initialStateRDD = sc.parallelize([])

def updateFunc(new_values, last_sum):
    return sum(new_values) + (last_sum or 0)

puerto = 21005
netCatStream = ssc.socketTextStream("localhost", puerto)

running_counts = (netCatStream.map(lambda author: (author, 1))
                  .updateStateByKey(updateFunc, initialRDD=initialStateRDD))

running_counts.pprint(10)
running_counts.saveAsTextFiles("/user/xcastanoa/running_counts", "txt")
ssc.start()
ssc.awaitTermination()
