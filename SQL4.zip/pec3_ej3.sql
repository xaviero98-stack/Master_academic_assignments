--Ejercicio 3

SET search_path TO supermarket;

WITH RECURSIVE hierarchy AS(
SELECT 
	employee_id,
	first_name,
	last_name,
	CAST(first_name || ' ' || last_name AS text) AS jerarquia
FROM 
	employees e
WHERE 
	reports_to IS NULL

UNION ALL

SELECT 
	e.employee_id,
	e.first_name,
	e.last_name,
	CAST(h.jerarquia ||'<-'|| e.first_name || ' ' || e.last_name AS text) AS jerarquia
FROM 
	employees e
	INNER JOIN hierarchy h
	ON e.reports_to = h.employee_id
)

SELECT
	h.employee_id,
	h.first_name,
	h.last_name,
	h.jerarquia,
	CASE
		WHEN reports_to IS NULL THEN 'Empleado Jefe'
		WHEN reports_to = '2' THEN 'Subordinado Directo'
		WHEN reports_to = '5' THEN 'Subordinado indirecto de nivel 2'
	END AS tipo_relacion
FROM
	hierarchy h
	INNER JOIN employees e
	ON e.employee_id = h.employee_id

