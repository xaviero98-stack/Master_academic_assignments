-- Ejercicio 5

--2)
SET search_path TO supermarket;
--a)
CREATE INDEX idx_product_id
ON products(product_id);
--b)
CREATE INDEX idx_supplier_name
ON suppliers(company_name);
--c)
CREATE INDEX idx_supplier_id_product
ON products(supplier_id);

--3)

EXPLAIN SELECT P.product_name,
S.company_name
FROM supermarket.products P,
supermarket.suppliers S
WHERE P.supplier_id = S.supplier_id
ORDER BY S.company_name ASC;