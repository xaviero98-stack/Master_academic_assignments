
--Ejercicio 1:

-- a)
SET search_path TO supermarket;

WITH products_rank AS (
  SELECT
    p.product_id,
    p.product_name,
    COUNT(DISTINCT o.order_id) AS num_orders,
    SUM(od.quantity) AS quantity,
    RANK() OVER (ORDER BY COUNT(DISTINCT o.order_id) DESC) AS rank
  FROM 
    products p,
	order_details od,
	orders o
  WHERE 
	od.order_id = o.order_id AND
	od.product_id = p.product_id
  GROUP BY
    p.product_id,
    p.product_name
)
SELECT
  product_id,
  product_name,
  num_orders,
  quantity
FROM
  products_rank
WHERE
  rank <= 14
ORDER BY
  num_orders DESC,
  product_name ASC;
  

-- b)

SET search_path TO supermarket;

WITH orders AS(
SELECT 
  s.company_name,
  ROUND(SUM(od.unit_price*quantity)::NUMERIC, 2) AS total_orders
FROM
  suppliers s
  LEFT JOIN products p
  ON s.supplier_id = p.supplier_id
  LEFT JOIN order_details od
  ON od.product_id = p.product_id
GROUP BY 
  s.company_name
), average AS (
SELECT 
  AVG(total_orders) AS average
FROM 
  orders
)

SELECT
  company_name,
  total_orders,
  ROUND((total_orders-a.average)::NUMERIC, 2) AS diff
  
FROM
  orders o
  CROSS JOIN average a
  
WHERE 
total_orders < average
 
ORDER BY 
 o.total_orders,
 o.company_name
  
  

