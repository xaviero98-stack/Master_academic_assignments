--Ejercicio 2

-- a)

SET search_path TO supermarket;

WITH pedido AS(
SELECT 
	product_name,
	order_id,
	company_name,
	od.unit_price * od.quantity AS valor_pedido,
	RANK() OVER (PARTITION BY p.product_id 
				 ORDER BY od.unit_price * od.quantity DESC) AS rk,
	AVG(od.unit_price * od.quantity) OVER (PARTITION BY p.product_name) AS avg_pedidos_producto
	
FROM 
	products p
	LEFT JOIN order_details od
	ON p.product_id = od.product_id
	LEFT JOIN suppliers s
	ON p.supplier_id = s.supplier_id
	
ORDER BY 
	product_name
)

SELECT 
	product_name,
	order_id,
	company_name,
	valor_pedido,
	avg_pedidos_producto
FROM
	pedido

WHERE 
	rk < 3
ORDER BY 
	product_name

-- b)

WITH productos AS(
SELECT
	company_name,
	product_name,
	COUNT(order_id) OVER (PARTITION BY p.product_name) AS num_pedidos,
	SUM(od.unit_price * od.quantity) OVER (PARTITION BY product_name) AS valor_proveedor_producto,
	SUM(od.unit_price * od.quantity) OVER (PARTITION BY company_name) AS ventas_proveedor
FROM
	suppliers s
	LEFT JOIN products p
	ON s.supplier_id = p.supplier_id
	LEFT JOIN order_details od
	ON od.product_id = p.product_id
ORDER BY
	company_name
), ranking AS(
SELECT 
	RANK() OVER (PARTITION BY company_name, product_name
				 ORDER BY valor_proveedor_producto DESC) AS rkg
FROM 
	productos
)

SELECT DISTINCT
	company_name,
	product_name,
	num_pedidos,
	ROUND(valor_proveedor_producto::NUMERIC, 2),
	rkg,
	ROUND(ventas_proveedor::NUMERIC, 2)
FROM
	productos,
	ranking
WHERE
	num_pedidos > 39
ORDER BY
	company_name,
	rkg
	