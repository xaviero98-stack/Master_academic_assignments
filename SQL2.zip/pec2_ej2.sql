
--Ejercicio 2

CREATE SCHEMA supermarket_dw;

SET search_path TO supermarket_dw;

CREATE TABLE tb_product_agg
(product_id SMALLINT NOT NULL PRIMARY KEY,
product_name VARCHAR(40) NOT NULL ,
unit_price NUMERIC (12,2),
order_count INT NOT NULL,
total_value NUMERIC(12,2) NOT NULL)


CREATE TABLE tb_supplier_agg
(supplier_id SMALLINT NOT NULL,
supplier_name VARCHAR(40) NOT NULL ,
category_name CHAR(15),
num_products BIGINT NOT NULL,
total_value NUMERIC(12,2) NOT NULL)

