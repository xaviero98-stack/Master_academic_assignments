--Preparación del ejercicio

SET search_path TO supermarket;

-- Ejercicio 1

--a)

SELECT s.supplier_id,
	   s.company_name,
	   c.category_name,
	   COUNT(DISTINCT product_id) AS num_products
FROM suppliers s
LEFT JOIN products p
ON s.supplier_id = p.supplier_id
LEFT JOIN categories c
ON p.category_id= c.category_id
GROUP BY s.supplier_id, c.category_name
ORDER BY company_name, category_name



-- b)

SET search_path TO supermarket;

SELECT p.product_id,
       product_name,
	   COUNT(o.order_id) AS num_orders
FROM orders o,
     order_details od,
	 products p
WHERE od.order_id = o.order_id AND
      p.product_id = od.product_id
GROUP BY p.product_id
HAVING COUNT(o.order_id)<10
ORDER BY COUNT(o.order_id)



-- c)

SELECT s.supplier_id,
       s.company_name,
	   COUNT(o.order_id) AS num_late_orders,
	   ROUND(AVG(o.shipped_date-o.required_date)::NUMERIC,2) AS avg_delay_days
FROM orders o, 
     order_details od,
	 products p,
	 categories c,
	 suppliers s
WHERE o.order_id = od.order_id AND
      od.product_id = p.product_id AND
	  p.supplier_id = s.supplier_id AND
	  p.category_id = c.category_id AND
	  required_date < shipped_date
GROUP BY s.supplier_id
HAVING COUNT(o.order_id)>5
ORDER BY num_late_orders DESC;


-- d)

SELECT p.product_id,
       p.product_name,
	   p.unit_price,
	   COUNT(od.order_id) AS order_count,
	   CASE 
	       WHEN SUM(od.quantity*od.unit_price) IS NULL THEN 0
		   ELSE ROUND(SUM(od.quantity*od.unit_price) :: NUMERIC, 2)
	   END AS total_value	   
FROM products p
LEFT JOIN order_details od
ON od.product_id = p.product_id
GROUP BY p.product_id
ORDER BY p.product_id;

-- e)

SELECT s.supplier_id,
       company_name,
	   category_name,
	   COUNT(product_id) AS num_products
FROM suppliers s
CROSS JOIN categories c
LEFT JOIN products p
ON p.supplier_id = s.supplier_id
GROUP BY s.supplier_id, c.category_name
ORDER BY category_name, num_products DESC, company_name;



