--Ejercicio 4

SET search_path TO supermarket_dw;

CREATE FUNCTION sp_load_supplier_agg() 
RETURNS void AS $$
DECLARE 
  fila_tabla tb_supplier_agg%rowtype;
BEGIN
DELETE FROM tb_supplier_agg;
  FOR fila_tabla IN 
       SELECT s.supplier_id,
       company_name AS supplier_name,
	   category_name,
	   COUNT(od.product_id) AS num_products,
	   CASE 
	   WHEN SUM(od.quantity*od.unit_price) IS NULL THEN 0
	   ELSE ROUND(SUM(od.quantity*od.unit_price)::NUMERIC, 2)
	   END AS total_value	   
       FROM supermarket.suppliers s
       LEFT JOIN supermarket.products p
       ON s.supplier_id = p.supplier_id
       LEFT JOIN supermarket.categories c
       ON p.category_id= c.category_id
       LEFT JOIN supermarket.order_details od
       ON od.product_id = p.product_id
       GROUP BY s.supplier_id, category_name
       ORDER BY company_name, category_name
  LOOP
  INSERT INTO tb_supplier_agg(supplier_id, supplier_name, category_name, num_products, total_value)
  VALUES (fila_tabla.supplier_id, fila_tabla.supplier_name, fila_tabla.category_name, fila_tabla.num_products, fila_tabla.total_value);
  END LOOP;
 END;
 $$ LANGUAGE plpgsql;
 
 SELECT * FROM sp_load_supplier_agg();
 