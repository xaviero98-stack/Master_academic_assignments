-- Ejercicio 3
SET search_path TO supermarket_dw;

CREATE OR REPLACE FUNCTION sp_load_product_agg()
  RETURNS void AS $$
DECLARE
  fila_tabla tb_product_agg%rowtype;
BEGIN
  DELETE FROM tb_product_agg;

  FOR fila_tabla IN
    SELECT p.product_id,
           p.product_name,
           p.unit_price,
           COUNT(od.order_id) AS order_count,
           CASE
             WHEN SUM(od.quantity*od.unit_price) IS NULL THEN 0
             ELSE ROUND(SUM(od.quantity*od.unit_price)::NUMERIC, 2)
           END AS total_value
    FROM supermarket.products p
    LEFT JOIN supermarket.order_details od ON od.product_id = p.product_id
    GROUP BY p.product_id
  LOOP
    INSERT INTO tb_product_agg (product_id, product_name, unit_price, order_count, total_value)
    VALUES (fila_tabla.product_id, fila_tabla.product_name, fila_tabla.unit_price, fila_tabla.order_count, fila_tabla.total_value);
  END LOOP;
  RETURN;
END;
$$ LANGUAGE plpgsql;

SELECT * FROM sp_load_product_agg();

