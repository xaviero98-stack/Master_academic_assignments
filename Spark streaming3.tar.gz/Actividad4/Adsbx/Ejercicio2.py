import findspark
findspark.init("/opt/cloudera/parcels/CDH-6.2.0-1.cdh6.2.0.p0.967373/lib/spark")
from pyspark.sql import SparkSession

from pyspark.sql.functions import explode,from_json,schema_of_json,lit,col
#Añade las importaciones que consideres necesarias

ejemplo='{"ac": [{"flight": "RYR80XN ","lat": 40.783493,"lon": -9.551697, "alt_baro": 37000,"category": "A3"}], "ctime": 1702444273059, "msg": "No error", "now": 1702444272731, "ptime": 6, "total": 146}'
encabezados = ['flight','lat','lon','alt_baro','category']  

spark = SparkSession.builder.appName("STRUCTURED STREAMING").getOrCreate()

schema = schema_of_json(ejemplo)

flujo = spark.readStream.format("socket").option("host", "localhost").option("port", 21005).load()

form_json = flujo.select(from_json(col("value"), schema).alias("value"))

formatted_json = form_json.select(explode(col("value.ac")).alias("value"))

df_spark = formatted_json.select(
    col("value.flight"),
    col("value.lat"),
    col("value.lon"),
    col("value.alt_baro"),
    col("value.category")
)

resultado= df_spark.writeStream.format("console").outputMode("append").start() #Salida por Consola de la información procesada

resultado.awaitTermination()

