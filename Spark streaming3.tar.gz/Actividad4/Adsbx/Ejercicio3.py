import findspark
findspark.init("/opt/cloudera/parcels/CDH-6.2.0-1.cdh6.2.0.p0.967373/lib/spark")
from pyspark.sql import SparkSession

from pyspark.sql.functions import explode,from_json,schema_of_json,lit,col,from_unixtime
#Añade las importaciones que consideres necesarias

ejemplo='{"ac": [{"flight": "RYR80XN ","lat": 40.783493,"lon": -9.551697, "alt_baro": 37000,"category": "A3"}], "ctime": 1702444273059, "msg": "No error", "now": 1702444272731, "ptime": 6, "total": 146}'
encabezados = ['flight','lat','lon','alt_baro','category']  

spark = SparkSession.builder.appName("STRUCTURED STREAMING").getOrCreate()

schema = schema_of_json(ejemplo)

flujo = spark.readStream.format("socket").option("host", "localhost").option("port", 21005).load()

form_json = flujo.select(from_json(col("value"), schema).alias("value"))

formatted_json = form_json.select(
    explode(col("value.ac")).alias("ac"), 
    col("value.now").alias("now")).select(
        col("ac.flight"),
        col("ac.lat"),
        col("ac.lon"),
        col("ac.alt_baro"),
        col("ac.category"),
        col("now")
    
).filter(
    (col("ac.lon") >= 0.500251) & (col("ac.lon") <= 3.567923) &
    (col("ac.lat") >= 40.294028) & (col("ac.lat") <= 42.924299)
).withColumn("timestamp", from_unixtime(col("now")/1000)).drop(col("now"))

resultado= formatted_json.writeStream.format("console").outputMode("append").start().awaitTermination()

