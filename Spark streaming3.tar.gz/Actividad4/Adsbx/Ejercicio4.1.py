import findspark
findspark.init("/opt/cloudera/parcels/CDH-6.2.0-1.cdh6.2.0.p0.967373/lib/spark")
from pyspark.sql import SparkSession

from pyspark.sql.functions import explode,from_json,schema_of_json,lit,col,sin,cos,pow,atan2,sqrt,radians,avg
#Añade las importaciones que consideres necesarias

ejemplo='{"ac": [{"flight": "RYR80XN ","lat": 40.783493,"lon": -9.551697, "alt_baro": 37000,"category": "A3"}], "ctime": 1702444273059, "msg": "No error", "now": 1702444272731, "ptime": 6, "total": 146}'
encabezados = ['flight','lat','lon','alt_baro','category']  

spark = SparkSession.builder.appName("STRUCTURED STREAMING").getOrCreate()

schema = schema_of_json(ejemplo)

flujo = spark.readStream.format("socket").option("host", "localhost").option("port", 21005).load()

form_json = flujo.select(from_json(col("value"), schema).alias("value"))

formatted_json = form_json.select(explode(col("value.ac")).alias("value"))

df_spark = formatted_json.select(
    col("value.flight"),
    col("value.lat"),
    col("value.lon"),
    col("value.alt_baro"),
    col("value.category")
)
df_spark_a_prat = df_spark.withColumn(
    "a_prat",
    pow(
        sin(radians(lit(41.29886422691005) - col("lat")) / 2), 2
    ) + cos(radians(col("lat"))) * cos(radians(lit(41.298799744238686))) * pow(
        sin(radians(lit(2.0792238768494897) - col("lon")) / 2), 2
    )
)
df_spark_dist_prat = df_spark_a_prat.withColumn(
    "dist_prat",
    atan2(
        sqrt(col("a_prat")),
        sqrt(lit(1) - col("a_prat"))
    ) * 2 * 6371
)

df_spark_a_tarr = df_spark_dist_prat.withColumn(
    "a_tarr",
    pow(
        sin(radians(lit(41.14842165486158) - col("lat")) / 2), 2
    ) + cos(radians(col("lat"))) * cos(radians(lit(41.14842165486158))) * pow(
        sin(radians(lit(1.1683052966307812) - col("lon")) / 2), 2
    )
)
df_spark_dist_tarr = df_spark_a_tarr.withColumn(
    "dist_tarr",
    atan2(
        sqrt(col("a_tarr")),
        sqrt(lit(1) - col("a_tarr"))
    ) * 2 * 6371
)

df_spark_a_gir = df_spark_dist_tarr.withColumn(
    "a_gir",
    pow(
        sin(radians(lit(41.897986042513296) - col("lat")) / 2), 2
    ) + cos(radians(col("lat"))) * cos(radians(lit(41.897986042513296))) * pow(
        sin(radians(lit(2.76599970409867) - col("lon")) / 2), 2
    )
)
df_spark_dist_gir = df_spark_a_gir.withColumn(
    "dist_gir",
    atan2(
        sqrt(col("a_gir")),
        sqrt(lit(1) - col("a_gir"))
    ) * 2 * 6371
)

df_spark_dist = df_spark_dist_gir.drop("a_prat", "a_tarr", "a_gir")

resultado= df_spark_dist.writeStream.format("console").outputMode("append").start() #Salida por Consola de la información procesada

resultado.awaitTermination()

